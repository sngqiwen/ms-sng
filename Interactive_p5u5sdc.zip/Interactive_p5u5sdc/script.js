// ============================================
// GAME STATE AND CONFIGURATION
// ============================================

// MODIFIED: Single word list with 15 specified words (no levels)
const wordList = [
    'wary',
    'initiative',
    'creativity',
    'sincerely',
    'annoying',
    'miserable',
    'distracted',
    'strategise',
    'impressed',
    'interactive',
    'convincing',
    'technology',
    'enthusiasm',
    'entertaining',
    'encourages'
];

// Celebration messages for game completion
const celebrationMessages = [
    "Fantastic spelling! 🌟",
    "You're a spelling champion! 🏆",
    "Excellent work! Keep it up! 🎯",
    "Amazing progress! 🚀",
    "Brilliant spelling skills! ✨"
];

// MODIFIED: Game state object - adjusted fall speed for slower dropping (2-3 more seconds)
let gameState = {
    score: 0,
    lives: 3,
    wordsCleared: 0,
    totalWords: 15,
    fallingWords: [],
    currentWords: [],
    gameActive: false,
    fallSpeed: 0.45, // MODIFIED: Reduced from 0.6 to 0.45 pixels per frame for slower fall (gives ~13 seconds for 600px height at 60fps, adding 2-3 more seconds)
    spawnInterval: 2500, // MODIFIED: Reduced from 3000 to 2500ms to allow multiple words on screen simultaneously
    lastSpawnTime: 0,
    animationFrame: null,
    isFirstWord: true // NEW: Track if this is the first word to spawn faster
};

// ============================================
// DOM ELEMENTS
// ============================================

const elements = {
    gameCanvas: document.getElementById('gameCanvas'),
    spellingInput: document.getElementById('spellingInput'),
    submitBtn: document.getElementById('submitBtn'),
    scoreDisplay: document.getElementById('scoreDisplay'),
    livesDisplay: document.getElementById('livesDisplay'),
    progressDisplay: document.getElementById('progressDisplay'),
    startOverlay: document.getElementById('startOverlay'),
    gameOverOverlay: document.getElementById('gameOverOverlay'),
    levelCompleteOverlay: document.getElementById('levelCompleteOverlay'),
    feedbackTooltip: document.getElementById('feedbackTooltip'),
    startBtn: document.getElementById('startBtn'),
    restartBtn: document.getElementById('restartBtn'),
    nextLevelBtn: document.getElementById('nextLevelBtn')
};

// ============================================
// INITIALIZATION
// ============================================

// Initialize event listeners when page loads
function init() {
    elements.startBtn.addEventListener('click', startGame);
    elements.restartBtn.addEventListener('click', resetGame);
    // MODIFIED: nextLevelBtn now restarts the game instead of advancing levels
    elements.nextLevelBtn.addEventListener('click', resetGame);
    elements.submitBtn.addEventListener('click', checkSpelling);
    
    // Allow Enter key to submit
    elements.spellingInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            checkSpelling();
        }
    });
    
    // Focus input when game starts
    elements.spellingInput.addEventListener('focus', () => {
        elements.spellingInput.select();
    });
}

// ============================================
// GAME FLOW FUNCTIONS
// ============================================

// Start the game
function startGame() {
    elements.startOverlay.classList.add('hidden');
    gameState.gameActive = true;
    // MODIFIED: Set lastSpawnTime to trigger first word immediately (subtract spawnInterval to make it spawn right away)
    gameState.lastSpawnTime = Date.now() - gameState.spawnInterval;
    gameState.isFirstWord = true; // NEW: Mark that the first word should spawn immediately
    elements.spellingInput.focus();
    
    // Shuffle and prepare words
    prepareWords();
    
    // Start game loop
    gameLoop();
}

// MODIFIED: Prepare words - simplified to use single word list
function prepareWords() {
    gameState.currentWords = shuffleArray([...wordList]);
}

// Main game loop - runs continuously during gameplay
function gameLoop() {
    if (!gameState.gameActive) return;
    
    const currentTime = Date.now();
    
    // MODIFIED: Spawn new word if enough time has passed and words remain
    // This allows multiple words to be on screen at the same time for increased challenge
    // MODIFIED: First word spawns immediately by checking isFirstWord flag
    if (currentTime - gameState.lastSpawnTime > gameState.spawnInterval && 
        gameState.currentWords.length > 0) {
        spawnWord();
        gameState.lastSpawnTime = currentTime;
        gameState.isFirstWord = false; // NEW: After first word, use normal timing
    }
    
    // Update all falling words
    updateFallingWords();
    
    // Continue loop
    gameState.animationFrame = requestAnimationFrame(gameLoop);
}

// Spawn a new falling word
function spawnWord() {
    if (gameState.currentWords.length === 0) return;
    
    const word = gameState.currentWords.shift();
    const wordElement = document.createElement('div');
    wordElement.className = 'falling-word';
    wordElement.textContent = word;
    wordElement.dataset.word = word;
    
    // Random horizontal position
    const maxX = elements.gameCanvas.offsetWidth - 150;
    const randomX = Math.random() * maxX;
    
    wordElement.style.left = randomX + 'px';
    wordElement.style.top = '0px';
    
    elements.gameCanvas.appendChild(wordElement);
    
    gameState.fallingWords.push({
        element: wordElement,
        word: word,
        y: 0
    });
}

// MODIFIED: Update positions of all falling words with slower fall speed (0.45 instead of 0.6)
function updateFallingWords() {
    const canvasHeight = elements.gameCanvas.offsetHeight;
    const dangerLine = canvasHeight - 3; // Bottom danger zone
    
    gameState.fallingWords.forEach((wordObj, index) => {
        // Move word down - now slower due to reduced fallSpeed (0.45 gives students 2-3 more seconds)
        wordObj.y += gameState.fallSpeed;
        wordObj.element.style.top = wordObj.y + 'px';
        
        // Check if word is in danger zone (near bottom)
        const wordBottom = wordObj.y + wordObj.element.offsetHeight;
        if (wordBottom > dangerLine - 50) {
            wordObj.element.classList.add('danger');
        }
        
        // Check if word touched the bottom
        if (wordBottom >= dangerLine) {
            loseLife();
            removeWord(index);
        }
    });
}

// Check if typed spelling is correct
function checkSpelling() {
    const typedWord = elements.spellingInput.value.trim().toLowerCase();
    
    if (!typedWord) return;
    
    // Check if typed word matches any falling word
    const matchIndex = gameState.fallingWords.findIndex(
        wordObj => wordObj.word.toLowerCase() === typedWord
    );
    
    if (matchIndex !== -1) {
        // Correct spelling!
        correctSpelling(matchIndex);
    } else {
        // Incorrect spelling
        incorrectSpelling();
    }
    
    // Clear input
    elements.spellingInput.value = '';
    elements.spellingInput.focus();
}

// Handle correct spelling
function correctSpelling(wordIndex) {
    const wordObj = gameState.fallingWords[wordIndex];
    
    // Show feedback
    showFeedback('✓ Correct!', 'correct');
    
    // Create particle effect
    createParticles(wordObj.element);
    
    // Update score and progress
    gameState.score += 10;
    gameState.wordsCleared++;
    
    // Remove word
    removeWord(wordIndex);
    
    // Update displays
    updateDisplays();
    
    // MODIFIED: Check if all 15 words are cleared (game complete)
    if (gameState.wordsCleared >= gameState.totalWords) {
        gameComplete();
    }
}

// Handle incorrect spelling
function incorrectSpelling() {
    showFeedback('✗ Try again!', 'incorrect');
    
    // Shake input field
    elements.spellingInput.style.animation = 'shake 0.3s';
    setTimeout(() => {
        elements.spellingInput.style.animation = '';
    }, 300);
}

// Remove a word from the game
function removeWord(index) {
    const wordObj = gameState.fallingWords[index];
    
    // Fade out animation
    wordObj.element.style.transition = 'all 0.3s';
    wordObj.element.style.opacity = '0';
    wordObj.element.style.transform = 'scale(0.5)';
    
    setTimeout(() => {
        if (wordObj.element.parentNode) {
            wordObj.element.parentNode.removeChild(wordObj.element);
        }
    }, 300);
    
    gameState.fallingWords.splice(index, 1);
}

// Lose a life when word reaches bottom
function loseLife() {
    gameState.lives--;
    updateDisplays();
    
    showFeedback('Word reached bottom! -1 Life', 'incorrect');
    
    if (gameState.lives <= 0) {
        gameOver();
    }
}

// MODIFIED: Game complete function (replaces levelComplete)
function gameComplete() {
    gameState.gameActive = false;
    cancelAnimationFrame(gameState.animationFrame);
    
    // Clear remaining words
    gameState.fallingWords.forEach(wordObj => {
        if (wordObj.element.parentNode) {
            wordObj.element.parentNode.removeChild(wordObj.element);
        }
    });
    gameState.fallingWords = [];
    
    // Show celebration
    const randomMessage = celebrationMessages[Math.floor(Math.random() * celebrationMessages.length)];
    document.getElementById('celebrationTitle').textContent = `🎉 You Win!`;
    document.getElementById('celebrationMessage').textContent = `${randomMessage} You cleared all 15 words with a score of ${gameState.score}!`;
    
    elements.levelCompleteOverlay.classList.remove('hidden');
}

// MODIFIED: Removed nextLevel function as there are no levels

// Game over
function gameOver() {
    gameState.gameActive = false;
    cancelAnimationFrame(gameState.animationFrame);
    
    // Clear all falling words
    gameState.fallingWords.forEach(wordObj => {
        if (wordObj.element.parentNode) {
            wordObj.element.parentNode.removeChild(wordObj.element);
        }
    });
    gameState.fallingWords = [];
    
    // Show game over screen
    document.getElementById('finalScore').textContent = `Final Score: ${gameState.score}`;
    document.getElementById('finalLevel').textContent = `You cleared ${gameState.wordsCleared} out of ${gameState.totalWords} words`;
    
    elements.gameOverOverlay.classList.remove('hidden');
}

// MODIFIED: Reset game to initial state with adjusted slower fall speed (0.45)
function resetGame() {
    elements.gameOverOverlay.classList.add('hidden');
    elements.levelCompleteOverlay.classList.add('hidden');
    
    // Reset game state - with slower fall speed (0.45) to give students 2-3 more seconds
    gameState = {
        score: 0,
        lives: 3,
        wordsCleared: 0,
        totalWords: 15,
        fallingWords: [],
        currentWords: [],
        gameActive: false,
        fallSpeed: 0.45, // Slower fall speed for 2-3 more seconds of typing time
        spawnInterval: 2500, // Shorter interval to allow multiple words on screen
        lastSpawnTime: 0,
        animationFrame: null,
        isFirstWord: true // NEW: Reset flag for first word to spawn immediately
    };
    
    updateDisplays();
    startGame();
}

// ============================================
// UI UPDATE FUNCTIONS
// ============================================

// MODIFIED: Update all display elements - removed level display
function updateDisplays() {
    elements.scoreDisplay.textContent = gameState.score;
    elements.progressDisplay.textContent = `${gameState.wordsCleared}/${gameState.totalWords}`;
    
    // Update lives display with hearts
    const hearts = '❤️'.repeat(gameState.lives);
    const emptyHearts = '🖤'.repeat(3 - gameState.lives);
    elements.livesDisplay.textContent = hearts + emptyHearts;
}

// Show feedback tooltip in center of screen
function showFeedback(message, type) {
    elements.feedbackTooltip.textContent = message;
    elements.feedbackTooltip.className = type;
    
    setTimeout(() => {
        elements.feedbackTooltip.classList.add('hidden');
    }, 1500);
}

// Create particle effect for correct answer
function createParticles(element) {
    const rect = element.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const colors = ['#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107'];
    
    for (let i = 0; i < 12; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = centerX + 'px';
        particle.style.top = centerY + 'px';
        particle.style.background = colors[Math.floor(Math.random() * colors.length)];
        
        const angle = (Math.PI * 2 * i) / 12;
        const distance = 50 + Math.random() * 50;
        const tx = Math.cos(angle) * distance;
        const ty = Math.sin(angle) * distance;
        
        particle.style.setProperty('--tx', tx + 'px');
        particle.style.setProperty('--ty', ty + 'px');
        
        document.body.appendChild(particle);
        
        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, 1000);
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Shuffle array using Fisher-Yates algorithm
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// ============================================
// START APPLICATION
// ============================================

// Initialize game when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}